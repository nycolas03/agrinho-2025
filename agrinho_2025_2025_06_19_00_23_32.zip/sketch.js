let veiculo;
let recursosCampo = [];
let recursosCidade = [];
let pontuacao = 0;
let tempoRestante = 60; // 60 segundos de jogo
let intervaloTempo;

function setup() {
  createCanvas(800, 600);
  veiculo = new Veiculo();

  // Iniciar o contador de tempo
  intervaloTempo = setInterval(contarTempo, 1000);
}

function draw() {
  background(220);

  // Desenha o campo (lado esquerdo)
  fill(144, 238, 144); // Verde claro
  rect(0, 0, width / 2, height);

  // Desenha a cidade (lado direito)
  fill(128, 128, 128); // Cinza
  rect(width / 2, 0, width / 2, height);

  // Desenha o veículo
  veiculo.mostrar();
  veiculo.mover();

  // Desenha recursos (exemplo)
  for (let recurso of recursosCampo) {
    recurso.mostrar();
  }
  for (let recurso of recursosCidade) {
    recurso.mostrar();
  }

  // Exibe pontuação e tempo
  fill(0);
  textSize(24);
  text(`Pontuação: ${pontuacao}`, 20, 30);
  text(`Tempo: ${floor(tempoRestante)}s`, width - 150, 30);

  // Lógica de fim de jogo
  if (tempoRestante <= 0) {
    clearInterval(intervaloTempo);
    // Exibir tela de fim de jogo
    fill(0);
    textSize(48);
    textAlign(CENTER, CENTER);
    text("Fim de Jogo!", width / 2, height / 2);
    noLoop(); // Para o loop draw
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    veiculo.setDirecao(-1, 0);
  } else if (keyCode === RIGHT_ARROW) {
    veiculo.setDirecao(1, 0);
  } else if (keyCode === UP_ARROW) {
    veiculo.setDirecao(0, -1);
  } else if (keyCode === DOWN_ARROW) {
    veiculo.setDirecao(0, 1);
  }
}

function keyReleased() {
  veiculo.setDirecao(0, 0); // Para o veículo quando a tecla é liberada
}

// Classe para o veículo
class Veiculo {
  constructor() {
    this.x = width / 4;
    this.y = height / 2;
    this.tamanho = 30;
    this.velocidade = 5;
    this.dx = 0;
    this.dy = 0;
    this.carga = 0;
    this.capacidadeMaxima = 3;
  }

  mostrar() {
    fill(255, 200, 0); // Amarelo/Laranja para o veículo
    rect(this.x, this.y, this.tamanho, this.tamanho);
    // Opcional: mostrar a carga no veículo
    fill(0);
    textSize(12);
    text(this.carga, this.x + this.tamanho / 2 - 5, this.y + this.tamanho / 2 + 5);
  }

  mover() {
    this.x += this.dx * this.velocidade;
    this.y += this.dy * this.velocidade;

    // Limites da tela
    this.x = constrain(this.x, 0, width - this.tamanho);
    this.y = constrain(this.y, 0, height - this.tamanho);
  }

  setDirecao(dx, dy) {
    this.dx = dx;
    this.dy = dy;
  }

  coletar(recurso) {
    if (this.carga < this.capacidadeMaxima) {
      this.carga++;
      return true; // Coletado com sucesso
    }
    return false; // Não foi possível coletar (capacidade máxima)
  }

  entregar() {
    if (this.carga > 0) {
      pontuacao += this.carga * 10; // Cada recurso entregue vale 10 pontos
      this.carga = 0;
      return true; // Entregue com sucesso
    }
    return false; // Não há nada para entregar
  }
}

// Classe para os recursos
class Recurso {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.tamanho = 20;
    this.tipo = tipo; // 'campo' ou 'cidade'
    this.coletado = false;
  }

  mostrar() {
    if (!this.coletado) {
      if (this.tipo === 'campo') {
        fill(100, 50, 0); // Marrom para recursos do campo (ex: semente)
        ellipse(this.x, this.y, this.tamanho, this.tamanho);
      } else {
        fill(0, 0, 200); // Azul para recursos da cidade (ex: peça)
        rect(this.x, this.y, this.tamanho, this.tamanho);
      }
    }
  }
}

// Função para gerar recursos (será chamada periodicamente)
function gerarRecurso() {
  // Gera recurso no campo
  if (random() < 0.7) { // Mais chance de gerar no campo
    let x = random(50, width / 2 - 50);
    let y = random(50, height - 50);
    recursosCampo.push(new Recurso(x, y, 'campo'));
  }

  // Gera recurso na cidade
  if (random() < 0.3) {
    let x = random(width / 2 + 50, width - 50);
    let y = random(50, height - 50);
    recursosCidade.push(new Recurso(x, y, 'cidade'));
  }

  // Remove recursos antigos ou coletados (para não sobrecarregar)
  recursosCampo = recursosCampo.filter(r => !r.coletado);
  recursosCidade = recursosCidade.filter(r => !r.coletado);
}

// Intervalo para gerar recursos a cada 2 segundos
setInterval(gerarRecurso, 2000);

// Função para o contador de tempo
function contarTempo() {
  tempoRestante--;
}

// Lógica de colisão e interação
function mousePressed() { // Usamos mousePressed para simular interação por enquanto
  // Lógica de coleta de recursos do campo
  for (let i = recursosCampo.length - 1; i >= 0; i--) {
    let r = recursosCampo[i];
    let d = dist(veiculo.x, veiculo.y, r.x, r.y);
    if (d < veiculo.tamanho / 2 + r.tamanho / 2 && !r.coletado && veiculo.carga < veiculo.capacidadeMaxima) {
      if (veiculo.x < width / 2) { // Somente coleta no campo se estiver no campo
        if (veiculo.coletar(r)) {
          r.coletado = true;
        }
      }
    }
  }

  // Lógica de coleta de recursos da cidade
  for (let i = recursosCidade.length - 1; i >= 0; i--) {
    let r = recursosCidade[i];
    let d = dist(veiculo.x, veiculo.y, r.x, r.y);
    if (d < veiculo.tamanho / 2 + r.tamanho / 2 && !r.coletado && veiculo.carga < veiculo.capacidadeMaxima) {
      if (veiculo.x >= width / 2) { // Somente coleta na cidade se estiver na cidade
        if (veiculo.coletar(r)) {
          r.coletado = true;
        }
      }
    }
  }

  // Lógica de entrega de recursos
  // Ponto de entrega no campo (se o veículo está na área do campo)
  if (veiculo.x < width / 2 && veiculo.carga > 0) {
    // Definir uma área de entrega no campo (ex: canto superior esquerdo)
    if (veiculo.x < 100 && veiculo.y < 100) {
      if (veiculo.entregar()) {
        console.log("Recursos entregues no campo!");
      }
    }
  }

  // Ponto de entrega na cidade (se o veículo está na área da cidade)
  if (veiculo.x >= width / 2 && veiculo.carga > 0) {
    // Definir uma área de entrega na cidade (ex: canto superior direito)
    if (veiculo.x > width - 100 - veiculo.tamanho && veiculo.y < 100) {
      if (veiculo.entregar()) {
        console.log("Recursos entregues na cidade!");
      }
    }
  }
}